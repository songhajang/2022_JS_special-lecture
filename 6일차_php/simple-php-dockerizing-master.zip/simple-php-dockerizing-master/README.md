docker-simple-php
=================

Basic usage of docker-compose for a general php app.

[The detail is here](https://www.haruair.com/blog/4430).
